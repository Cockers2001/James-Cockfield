﻿namespace SyntxError.Forms
{
    partial class frmProgress
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlLeftSide = new System.Windows.Forms.Panel();
            this.pnlOnButtonPosition = new System.Windows.Forms.Panel();
            this.Label19 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.picClose = new System.Windows.Forms.PictureBox();
            this.picMaximize = new System.Windows.Forms.PictureBox();
            this.picMinimize = new System.Windows.Forms.PictureBox();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnLessons = new System.Windows.Forms.Button();
            this.btnProgress = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.pnlLeftSide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMaximize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMinimize)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlLeftSide
            // 
            this.pnlLeftSide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.pnlLeftSide.Controls.Add(this.picClose);
            this.pnlLeftSide.Controls.Add(this.picMaximize);
            this.pnlLeftSide.Controls.Add(this.pnlOnButtonPosition);
            this.pnlLeftSide.Controls.Add(this.picMinimize);
            this.pnlLeftSide.Controls.Add(this.Label19);
            this.pnlLeftSide.Controls.Add(this.Label16);
            this.pnlLeftSide.Controls.Add(this.btnAbout);
            this.pnlLeftSide.Controls.Add(this.btnProfile);
            this.pnlLeftSide.Controls.Add(this.btnLessons);
            this.pnlLeftSide.Controls.Add(this.btnProgress);
            this.pnlLeftSide.Controls.Add(this.btnHome);
            this.pnlLeftSide.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLeftSide.Location = new System.Drawing.Point(0, 0);
            this.pnlLeftSide.Name = "pnlLeftSide";
            this.pnlLeftSide.Size = new System.Drawing.Size(200, 498);
            this.pnlLeftSide.TabIndex = 2;
            // 
            // pnlOnButtonPosition
            // 
            this.pnlOnButtonPosition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(138)))), ((int)(((byte)(7)))));
            this.pnlOnButtonPosition.Location = new System.Drawing.Point(0, 170);
            this.pnlOnButtonPosition.Name = "pnlOnButtonPosition";
            this.pnlOnButtonPosition.Size = new System.Drawing.Size(10, 37);
            this.pnlOnButtonPosition.TabIndex = 1;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.ForeColor = System.Drawing.SystemColors.Control;
            this.Label19.Location = new System.Drawing.Point(94, 35);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(67, 29);
            this.Label19.TabIndex = 11;
            this.Label19.Text = "Error";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.ForeColor = System.Drawing.SystemColors.Control;
            this.Label16.Location = new System.Drawing.Point(12, 35);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(89, 29);
            this.Label16.TabIndex = 10;
            this.Label16.Text = "Syntax";
            // 
            // picClose
            // 
            this.picClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(17)))), ((int)(((byte)(21)))));
            this.picClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picClose.Image = global::SyntxError.Properties.Resources.btnClose;
            this.picClose.Location = new System.Drawing.Point(3, 3);
            this.picClose.Name = "picClose";
            this.picClose.Size = new System.Drawing.Size(18, 18);
            this.picClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picClose.TabIndex = 15;
            this.picClose.TabStop = false;
            // 
            // picMaximize
            // 
            this.picMaximize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picMaximize.Image = global::SyntxError.Properties.Resources.btnMaximize;
            this.picMaximize.Location = new System.Drawing.Point(45, 3);
            this.picMaximize.Name = "picMaximize";
            this.picMaximize.Size = new System.Drawing.Size(18, 18);
            this.picMaximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMaximize.TabIndex = 17;
            this.picMaximize.TabStop = false;
            // 
            // picMinimize
            // 
            this.picMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picMinimize.Image = global::SyntxError.Properties.Resources.btnMinimize;
            this.picMinimize.Location = new System.Drawing.Point(24, 3);
            this.picMinimize.Name = "picMinimize";
            this.picMinimize.Size = new System.Drawing.Size(18, 18);
            this.picMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMinimize.TabIndex = 16;
            this.picMinimize.TabStop = false;
            // 
            // btnAbout
            // 
            this.btnAbout.FlatAppearance.BorderSize = 0;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAbout.Location = new System.Drawing.Point(0, 260);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(200, 37);
            this.btnAbout.TabIndex = 22;
            this.btnAbout.Text = "   About";
            this.btnAbout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAbout.UseVisualStyleBackColor = true;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.ForeColor = System.Drawing.SystemColors.Control;
            this.btnProfile.Location = new System.Drawing.Point(0, 215);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(200, 37);
            this.btnProfile.TabIndex = 21;
            this.btnProfile.Text = "Profile";
            this.btnProfile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnProfile.UseVisualStyleBackColor = true;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnLessons
            // 
            this.btnLessons.FlatAppearance.BorderSize = 0;
            this.btnLessons.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLessons.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLessons.ForeColor = System.Drawing.SystemColors.Control;
            this.btnLessons.Location = new System.Drawing.Point(0, 125);
            this.btnLessons.Name = "btnLessons";
            this.btnLessons.Size = new System.Drawing.Size(200, 37);
            this.btnLessons.TabIndex = 20;
            this.btnLessons.Text = "Lessons";
            this.btnLessons.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLessons.UseVisualStyleBackColor = true;
            this.btnLessons.Click += new System.EventHandler(this.btnLessons_Click);
            // 
            // btnProgress
            // 
            this.btnProgress.FlatAppearance.BorderSize = 0;
            this.btnProgress.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProgress.ForeColor = System.Drawing.SystemColors.Control;
            this.btnProgress.Location = new System.Drawing.Point(0, 170);
            this.btnProgress.Name = "btnProgress";
            this.btnProgress.Size = new System.Drawing.Size(200, 37);
            this.btnProgress.TabIndex = 19;
            this.btnProgress.Text = "Progress";
            this.btnProgress.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnProgress.UseVisualStyleBackColor = true;
            this.btnProgress.Click += new System.EventHandler(this.btnProgress_Click);
            // 
            // btnHome
            // 
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.SystemColors.Control;
            this.btnHome.Location = new System.Drawing.Point(0, 80);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(200, 37);
            this.btnHome.TabIndex = 18;
            this.btnHome.Text = "Home";
            this.btnHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // frmProgress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 498);
            this.Controls.Add(this.pnlLeftSide);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmProgress";
            this.Text = "frmProgress";
            this.pnlLeftSide.ResumeLayout(false);
            this.pnlLeftSide.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMaximize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMinimize)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel pnlLeftSide;
        internal System.Windows.Forms.PictureBox picClose;
        internal System.Windows.Forms.PictureBox picMaximize;
        internal System.Windows.Forms.Panel pnlOnButtonPosition;
        internal System.Windows.Forms.PictureBox picMinimize;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Button btnAbout;
        internal System.Windows.Forms.Button btnProfile;
        internal System.Windows.Forms.Button btnLessons;
        internal System.Windows.Forms.Button btnProgress;
        internal System.Windows.Forms.Button btnHome;
    }
}