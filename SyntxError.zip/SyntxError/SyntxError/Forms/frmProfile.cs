﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SyntxError.Forms
{
    public partial class frmProfile : Form
    {
        public frmProfile()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Hide();
            new frmHome().Show();
        }

        private void btnLessons_Click(object sender, EventArgs e)
        {
            Hide();
            new frmLessons().Show();
        }

        private void btnProgress_Click(object sender, EventArgs e)
        {
            Hide();
            new frmProgress().Show();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            Hide();
            new frmProfile().Show();
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            Hide();
            new frmAbout().Show();
        }
    }
}
